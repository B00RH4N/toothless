<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <!-- Boxicons -->
    <link href='https://unpkg.com/boxicons@2.0.9/css/boxicons.min.css' rel='stylesheet'>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <!-- My CSS -->
    <link rel="stylesheet" href="<?php echo e(asset('css/productdetail.css')); ?>">

    <title>AdminHub</title>
</head>

<body>
    <?php echo $__env->make('sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>;

    <!-- CONTENT -->
    <section id="content">
        <?php echo $__env->make('navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>;

        <!-- MAIN -->
        <main>
            <div class="head-title">
                <div class="left">
                    <button><a href="/productlist">Back</a></button>
                </div>
                <div class="right">
                    <form method="post" action="<?php echo e(route('deleteProduct', $filteredProduct->productCode)); ?>">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('DELETE'); ?>
                        <button type="submit"><i class="fa fa-trash-o"></i></button>
                    </form>
                </div>
            </div>

            <div class="table-data">
                <div class="order">
                    <form method="post" action="<?php echo e(route('updateProduct', $filteredProduct->productCode)); ?>">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('PUT'); ?>
                        <div class="head">
                            <input type="text" value="<?php echo e($filteredProduct->productName); ?>" name="productName">
                        </div>
                        <div>
                            <img class="fotoProduk" src="<?php echo e($filteredProduct->productImage); ?>">
                            <h>Price</h>
                            <input type="text" value="<?php echo e($filteredProduct->productPrice); ?>" name="productPrice">

                            <!-- <h class="qty">Quantity In Stock</h> -->
                            <div class="qtyIncrementDecrement">
                                <h class="qty">Quantity In Stock</h>
                                <i class="fa fa-minus-circle"></i>
                                <input type="text" class="num" value="<?php echo e($filteredProduct->dailyStock); ?>" name="dailyStock" readonly>
                                <i class="fa fa-plus-circle"></i>
                            </div>

                            <h>Category</h>
                            <select id="categorySelect" name="category">
                                <?php $__currentLoopData = $enumValues; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($value); ?>" <?php echo e($filteredProduct->productCategory == $value ? 'selected' : ''); ?>>
                                    <?php echo e($value); ?>

                                </option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>

                            <div class="gantiDescription">
                            <h>Product Description</h>
                            <input type="text" value="<?php echo e($filteredProduct->productDescription); ?>" name="productDescription">
                            <!-- <button type="submit">Update</button> -->
                            </div>
                            <button type="submit">Update</button>
                        </div>
                    </form>
                </div>
            </div>
        </main>
        <!-- MAIN -->
    </section>
    <!-- CONTENT -->


    <script src="<?php echo e(asset('js/sidebar.js')); ?>"></script>
    <script src="<?php echo e(asset('js/quantity.js')); ?>"></script>
</body>

</html><?php /**PATH C:\xampp\htdocs\projectlaravel\resources\views/productdetail.blade.php ENDPATH**/ ?>