<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <!-- Boxicons -->
    <link href='https://unpkg.com/boxicons@2.0.9/css/boxicons.min.css' rel='stylesheet'>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <!-- My CSS -->
    <link rel="stylesheet" href="<?php echo e(asset('css/productlist.css')); ?>">

    <title>AdminHub</title>
</head>

<body>
    <?php echo $__env->make('sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>;

    <!-- CONTENT -->
    <section id="content">
        <?php echo $__env->make('navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>;

        <!-- MAIN -->
        <main>
            <div class="head-title">
                <div class="left">
                    <h1>Products</h1>
                </div>
                <div class="right">
                    <a href="/createproduct" class="add"><i class="fa fa-plus-circle"></i></a>
                </div>
            </div>


            <div class="table-data">
                <div class="order">
                    <div class="head">
                        <h3>Products</h3>
                        <i class='bx bx-search'></i>
                        <i class='bx bx-filter'></i>
                    </div>
                    <table>
                        <thead>
                            <tr>
                                <th>Product Image</th>
                                <th>Product ID</th>
                                <th>Product Name</th>
                                <th>Product Price</th>
                                <th>Product Category</th>
                                <th>Quantity In Stock</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr onclick="onpress('<?php echo e($product->productCode); ?>')">
                                <td>
                                    <img src="<?php echo e($product->productImage); ?>">
                                </td>
                                <td><?php echo e($product->productCode); ?></td>
                                <td><?php echo e($product->productName); ?></td>
                                <td><?php echo e($product->productPrice); ?></td>
                                <td><?php echo e($product->productCategory); ?></td>
                                <td><?php echo e($product->dailyStock); ?></td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
        </main>
        <!-- MAIN -->
    </section>
    <!-- CONTENT -->


    <script src="<?php echo e(asset('js/sidebar.js')); ?>"></script>
    <script src="<?php echo e(asset('js/onpress.js')); ?>"></script>
</body>

</html><?php /**PATH C:\xampp\htdocs\projectlaravel\resources\views/productlist.blade.php ENDPATH**/ ?>