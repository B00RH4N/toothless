<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <!-- Boxicons -->
    <link href='https://unpkg.com/boxicons@2.0.9/css/boxicons.min.css' rel='stylesheet'>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <!-- My CSS -->
    <link rel="stylesheet" href="<?php echo e(asset('css/createproduct.css')); ?>">

    <title>AdminHub</title>
</head>

<body>
    <?php echo $__env->make('sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>;

    <!-- CONTENT -->
    <section id="content">
        <?php echo $__env->make('navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>;

        <!-- MAIN -->
        <main>
            <div class="head-title">
                <div class="left">
                    <button><a href="/productlist">Back</a></button>
                </div>
            </div>


            <div class="table-data">
                <div class="order">
                    <div class="head">
                        <h3>Create Product</h3>
                    </div>
                    <table>
                        <form action="<?php echo e(route('createProduct')); ?>" method="POST">
                            <?php echo csrf_field(); ?>
                            <h>Item Name</h>
                            <input type="text" name="productName">

                            <div>
                            <h>Image Url</h>
                            <input type="text" name="productImage">
                            </div>

                            <h>Price</h>
                            <input type="text" name="productPrice">

                            <!-- <h>Quantity In Stock</h> -->
                            <div class="qtyIncrementDecrement">
                                <h>Quantity In Stock</h>
                                <i class="fa fa-minus-circle"></i>
                                <input type="text" class="num" value="1" name="dailyStock" readonly>
                                <i class="fa fa-plus-circle"></i>
                            </div>

                            <h>Category</h>
                            <select id="categorySelect" name="category">
                                <?php $__currentLoopData = $enumValues; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($value); ?>"><?php echo e($value); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                            
                            <div>
                            <h>Product Description</h>
                            <input type="text" name="productDescription">
                            </div>

                            <button type="submit">Create</button>
                        </form>
                    </table>
                </div>

            </div>
        </main>
        <!-- MAIN -->
    </section>
    <!-- CONTENT -->

    <script src="<?php echo e(asset('js/sidebar.js')); ?>"></script>
    <script src="<?php echo e(asset('js/quantity.js')); ?>"></script>
</body>

</html><?php /**PATH C:\xampp\htdocs\projectlaravel\resources\views/createproduct.blade.php ENDPATH**/ ?>