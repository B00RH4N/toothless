function onpress(productCode) {
    var url = "/productdetail/__productCode__";
    url = url.replace('__productCode__', productCode);
    window.location.href = url;
}