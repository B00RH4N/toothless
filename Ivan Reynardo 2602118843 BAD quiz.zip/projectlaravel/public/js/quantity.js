document.addEventListener("DOMContentLoaded", function () {
    const plus = document.querySelector(".fa.fa-plus-circle"),
          minus = document.querySelector(".fa.fa-minus-circle"),
          numInput = document.querySelector(".qtyIncrementDecrement input.num");

    let quantity = parseInt(numInput.value, 10) || 1;

    function updateQuantity() {
        numInput.value = quantity;
        console.log(quantity);
    }

    plus.addEventListener("click", () => {
        quantity++;
        updateQuantity();
    }); 

    minus.addEventListener("click", () => {
        if (quantity > 1) {
            quantity--;
            updateQuantity();
        }
    });
});
