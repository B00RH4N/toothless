<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\authenticationController;
use App\Http\Controllers\orderController;
use App\Http\Controllers\productController;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider and all of them will
| be assigned to the "web" middleware group. Make something great!
|
*/

Route::get('/', [authenticationController::class, 'index']);

Route::post('/login', [authenticationController::class, 'login'])->name('login.post');

Route::match(['get', 'post'], '/dashboard', [authenticationController::class, 'dashboard'])->name('dashboard');

Route::get('/productlist', [productController::class, 'viewProductList'])->name('productList');

Route::get('/productdetail/{productCode}', [productController::class, 'viewProductDetail']);

Route::get('/createproduct', [productController::class, 'viewCreateProduct'])->name('createProductView');

Route::get('/orderlist', [orderController::class, 'viewOrderList']);

Route::post('/update-product', [productController::class, 'createProduct'])->name('createProduct');

Route::put('/updateProduct/{productCode}', [ProductController::class, 'updateProduct'])->name('updateProduct');

Route::delete('/deleteProduct/{productCode}', [ProductController::class, 'destroy'])->name('deleteProduct');