<!-- SIDEBAR -->
<section id="sidebar">
	<a href="#" class="brand">
		<img src="https://logo.com/image-cdn/images/kts928pd/production/0089b7ae1ed394f041c5f7929e111c11e8eafe4d-424x421.png?w=1080&q=72" class="logo">
		<span class="text">Ecommerce</span>
	</a>
	<ul class="side-menu top">
		<li class="{{request()->is('dashboard') ? 'active' : ''}}">
			<a href="/dashboard">
				<i class='bx bxs-dashboard'></i>
				<span class="text">Dashboard</span>
			</a>
		</li>
		<li class="{{request()->is('productlist') ? 'active' : ''}}">
			<a href="/productlist">
				<i class='bx bxs-shopping-bag-alt'></i>
				<span class="text">Products</span>
			</a>
		</li>
		<li class="{{request()->is('orderlist') ? 'active' : ''}}">
			<a href="/orderlist">
				<i class='bx bxs-doughnut-chart'></i>
				<span class="text">Orders</span>
			</a>
		</li>
		<ul class="side-menu">
			<li>
				<a href="#">
					<i class='bx bxs-cog'></i>
					<span class="text">Settings</span>
				</a>
			</li>
			<li>
				<a href="#" class="logout">
					<i class='bx bxs-log-out-circle'></i>
					<span class="text">Logout</span>
				</a>
			</li>
		</ul>
</section>
<!-- SIDEBAR -->