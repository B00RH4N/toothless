<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <!-- Boxicons -->
    <link href='https://unpkg.com/boxicons@2.0.9/css/boxicons.min.css' rel='stylesheet'>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <!-- My CSS -->
    <link rel="stylesheet" href="{{asset('css/createproduct.css')}}">

    <title>AdminHub</title>
</head>

<body>
    @include('sidebar');

    <!-- CONTENT -->
    <section id="content">
        @include('navbar');

        <!-- MAIN -->
        <main>
            <div class="head-title">
                <div class="left">
                    <button><a href="/productlist">Back</a></button>
                </div>
            </div>


            <div class="table-data">
                <div class="order">
                    <div class="head">
                        <h3>Create Product</h3>
                    </div>
                    <table>
                        <form action="{{ route('createProduct') }}" method="POST">
                            @csrf
                            <h>Item Name</h>
                            <input type="text" name="productName">

                            <div>
                            <h>Image Url</h>
                            <input type="text" name="productImage">
                            </div>

                            <h>Price</h>
                            <input type="text" name="productPrice">

                            <!-- <h>Quantity In Stock</h> -->
                            <div class="qtyIncrementDecrement">
                                <h>Quantity In Stock</h>
                                <i class="fa fa-minus-circle"></i>
                                <input type="text" class="num" value="1" name="dailyStock" readonly>
                                <i class="fa fa-plus-circle"></i>
                            </div>

                            <h>Category</h>
                            <select id="categorySelect" name="category">
                                @foreach($enumValues as $value)
                                <option value="{{ $value }}">{{ $value }}</option>
                                @endforeach
                            </select>
                            
                            <div>
                            <h>Product Description</h>
                            <input type="text" name="productDescription">
                            </div>

                            <button type="submit">Create</button>
                        </form>
                    </table>
                </div>

            </div>
        </main>
        <!-- MAIN -->
    </section>
    <!-- CONTENT -->

    <script src="{{asset('js/sidebar.js')}}"></script>
    <script src="{{asset('js/quantity.js')}}"></script>
</body>

</html>