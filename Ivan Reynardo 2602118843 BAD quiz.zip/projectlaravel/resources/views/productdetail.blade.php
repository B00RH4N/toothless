<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <!-- Boxicons -->
    <link href='https://unpkg.com/boxicons@2.0.9/css/boxicons.min.css' rel='stylesheet'>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <!-- My CSS -->
    <link rel="stylesheet" href="{{asset('css/productdetail.css')}}">

    <title>AdminHub</title>
</head>

<body>
    @include('sidebar');

    <!-- CONTENT -->
    <section id="content">
        @include('navbar');

        <!-- MAIN -->
        <main>
            <div class="head-title">
                <div class="left">
                    <button><a href="/productlist">Back</a></button>
                </div>
                <div class="right">
                    <form method="post" action="{{ route('deleteProduct', $filteredProduct->productCode) }}">
                        @csrf
                        @method('DELETE')
                        <button type="submit"><i class="fa fa-trash-o"></i></button>
                    </form>
                </div>
            </div>

            <div class="table-data">
                <div class="order">
                    <form method="post" action="{{ route('updateProduct', $filteredProduct->productCode) }}">
                        @csrf
                        @method('PUT')
                        <div class="head">
                            <input type="text" value="{{$filteredProduct->productName}}" name="productName">
                        </div>
                        <div>
                            <img class="fotoProduk" src="{{$filteredProduct->productImage}}">
                            <h>Price</h>
                            <input type="text" value="{{$filteredProduct->productPrice}}" name="productPrice">

                            <!-- <h class="qty">Quantity In Stock</h> -->
                            <div class="qtyIncrementDecrement">
                                <h class="qty">Quantity In Stock</h>
                                <i class="fa fa-minus-circle"></i>
                                <input type="text" class="num" value="{{$filteredProduct->dailyStock}}" name="dailyStock" readonly>
                                <i class="fa fa-plus-circle"></i>
                            </div>

                            <h>Category</h>
                            <select id="categorySelect" name="category">
                                @foreach($enumValues as $value)
                                <option value="{{ $value }}" {{ $filteredProduct->productCategory == $value ? 'selected' : '' }}>
                                    {{ $value }}
                                </option>
                                @endforeach
                            </select>

                            <div class="gantiDescription">
                            <h>Product Description</h>
                            <input type="text" value="{{$filteredProduct->productDescription}}" name="productDescription">
                            <!-- <button type="submit">Update</button> -->
                            </div>
                            <button type="submit">Update</button>
                        </div>
                    </form>
                </div>
            </div>
        </main>
        <!-- MAIN -->
    </section>
    <!-- CONTENT -->


    <script src="{{asset('js/sidebar.js')}}"></script>
    <script src="{{asset('js/quantity.js')}}"></script>
</body>

</html>