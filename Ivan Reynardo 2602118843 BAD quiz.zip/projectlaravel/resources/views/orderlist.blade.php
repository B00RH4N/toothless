<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <!-- Boxicons -->
    <link href='https://unpkg.com/boxicons@2.0.9/css/boxicons.min.css' rel='stylesheet'>
    <!-- My CSS -->
    <link rel="stylesheet" href="{{asset('css/orderlist.css')}}">

    <title>AdminHub</title>
</head>

<body>
    @include('sidebar');

    <!-- CONTENT -->
    <section id="content">
        @include('navbar');

        <!-- MAIN -->
        <main>
            <div class="head-title">
                <div class="left">
                    <h1>Orders</h1>
                </div>
            </div>


            <div class="table-data">
                <div class="order">
                    <div class="head">
                        <h3>Orders</h3>
                        <i class='bx bx-search'></i>
                        <i class='bx bx-filter'></i>
                    </div>
                    <table>
                        <thead>
                            <tr>
                                <th>Order ID</th>
                                <th>Date Order</th>
                                <th>Status</th>
                            </tr>
                        </thead>
                        <tbody>
                            @foreach($orders as $order)
                            <tr>
                                <td>
                                    <p>{{$order->orderCode}}</p>
                                </td>
                                <td>{{$order->orderDateTime}}</td>
                                <td><span class="status {{ strtolower($order->orderStatus) }}">{{$order->orderStatus}}</span></td>
                            </tr>
                            @endforeach
                        </tbody>
                    </table>
                </div>
        </main>
        <!-- MAIN -->
    </section>
    <!-- CONTENT -->


    <script src="{{asset('js/sidebar.js')}}"></script>
</body>

</html>