<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <link rel="stylesheet" href="{{ asset('css/login.css') }}" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>

<body>
    <div class="container">
        <div class="Supra">
            <div class="GT-R">
                <img src="https://logo.com/image-cdn/images/kts928pd/production/0089b7ae1ed394f041c5f7929e111c11e8eafe4d-424x421.png?w=1080&q=72" class="logo">
            </div>
            <div class="Rx7">
                <h>Login</h>
                <form action="{{ route('login.post') }}" method="post" class="inputField">
                    @csrf
                    <input type="email" name="email" class="email" placeholder="email">
                    <input type="password" name="password" class="password" placeholder="password">
                    <button type="submit" class="login">Login</button>
                </form>
            </div>
        </div>
    </div>
</body>

</html>