<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <!-- Boxicons -->
    <link href='https://unpkg.com/boxicons@2.0.9/css/boxicons.min.css' rel='stylesheet'>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <!-- My CSS -->
    <link rel="stylesheet" href="{{asset('css/productlist.css')}}">

    <title>AdminHub</title>
</head>

<body>
    @include('sidebar');

    <!-- CONTENT -->
    <section id="content">
        @include('navbar');

        <!-- MAIN -->
        <main>
            <div class="head-title">
                <div class="left">
                    <h1>Products</h1>
                </div>
                <div class="right">
                    <a href="/createproduct" class="add"><i class="fa fa-plus-circle"></i></a>
                </div>
            </div>


            <div class="table-data">
                <div class="order">
                    <div class="head">
                        <h3>Products</h3>
                        <i class='bx bx-search'></i>
                        <i class='bx bx-filter'></i>
                    </div>
                    <table>
                        <thead>
                            <tr>
                                <th>Product Image</th>
                                <th>Product ID</th>
                                <th>Product Name</th>
                                <th>Product Price</th>
                                <th>Product Category</th>
                                <th>Quantity In Stock</th>
                            </tr>
                        </thead>
                        <tbody>
                            @foreach($products as $product)
                            <tr onclick="onpress('{{ $product->productCode }}')">
                                <td>
                                    <img src="{{$product->productImage}}">
                                </td>
                                <td>{{$product->productCode}}</td>
                                <td>{{$product->productName}}</td>
                                <td>{{$product->productPrice}}</td>
                                <td>{{$product->productCategory}}</td>
                                <td>{{$product->dailyStock}}</td>
                            </tr>
                            @endforeach
                        </tbody>
                    </table>
                </div>
        </main>
        <!-- MAIN -->
    </section>
    <!-- CONTENT -->


    <script src="{{asset('js/sidebar.js')}}"></script>
    <script src="{{asset('js/onpress.js')}}"></script>
</body>

</html>