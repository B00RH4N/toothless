<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\product;

class productController extends Controller
{
    //
    public function viewProductList()
    {
        $products = product::all();
        return view('productlist', ['products' => $products]);
    }
    public function viewProductDetail($productCode)
    {
        $filteredProduct = Product::where('productCode', $productCode)->first();

        $enumValues = Product::getEnumValues('product', 'productCategory');

        return view('productdetail', ['filteredProduct' => $filteredProduct], ['enumValues' => $enumValues]);
    }
    public function viewCreateProduct()
    {
        $enumValues = Product::getEnumValues('product', 'productCategory');

        return view('createproduct', ['enumValues' => $enumValues]);
    }
    public function createProduct(Request $request)
    {
        $product = new Product;

        $product->productName = $request->input('productName');
        $product->productPrice = $request->input('productPrice');
        $product->dailyStock = $request->input('dailyStock');
        $product->productCategory = $request->input('category');
        $product->productDescription = $request->input('productDescription');
        $product->productImage = $request->input('productImage');
        $product->save();

        // Redirect or perform any other actions as needed
        return redirect()->route('productList')->with('success', 'Product added successfully');
    }
    public function updateProduct(Request $request, $productCode)
    {
        $product = Product::where('productCode', $productCode)->first();

        $product->productName = $request->input('productName');
        $product->productPrice = $request->input('productPrice');
        $product->dailyStock = $request->input('dailyStock');
        $product->productCategory = $request->input('category');
        $product->productDescription = $request->input('productDescription');
        $product->save();

        return redirect()->back()->with('success', 'Product updated successfully');
    }

    public function destroy($productCode)
    {
        $product = Product::where('productCode', $productCode)->first();

        if (!$product) {
            return redirect()->route('updateProduct')->with('error', 'Product not found');
        }

        $product->delete();

        return redirect()->route('productList')->with('success', 'Product deleted successfully');
    }
}
