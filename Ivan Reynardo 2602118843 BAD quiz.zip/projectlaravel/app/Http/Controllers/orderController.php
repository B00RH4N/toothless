<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\order;

class orderController extends Controller
{
    //
    public function viewOrderList() {
        $orders = order::all();
        return view('orderlist', ['orders' => $orders]);
    }
}
