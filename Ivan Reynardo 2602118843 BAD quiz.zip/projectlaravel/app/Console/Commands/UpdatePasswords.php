<?php

// app/Console/Commands/UpdatePasswords.php

namespace App\Console\Commands;

use Illuminate\Console\Command;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Hash;

class UpdatePasswords extends Command
{
    protected $signature = 'update:passwords';

    protected $description = 'Update existing passwords to use Bcrypt hashing';

    public function handle()
    {
        $this->info('Updating passwords...');

        // Retrieve users with plaintext passwords
        $users = DB::table('User')->where('password', '!=', '')->get();

        foreach ($users as $user) {
            // Update each user's password to use Bcrypt
            DB::table('User')->where('userID', $user->userID)->update([
                'password' => Hash::make($user->password),
            ]);
        }

        $this->info('Passwords updated successfully.');
    }
}
